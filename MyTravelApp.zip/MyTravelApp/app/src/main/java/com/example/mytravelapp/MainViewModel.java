package com.example.mytravelapp;

public class MainViewModel {
}
